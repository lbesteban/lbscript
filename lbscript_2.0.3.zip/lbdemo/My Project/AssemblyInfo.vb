﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("LB Demo")> 
<Assembly: AssemblyDescription("SAPGui Scripting demo for LBScript")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("LBDemo")> 
<Assembly: AssemblyCopyright("Academic Free License / Artistic License 2.0")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("39456fd5-6df7-4300-ba37-1ecc00134ffc")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("2.0.3.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
